/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sugandhakher
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public abstract class JButtonEx extends JFrame implements ActionListener {

    JButton one;
    JButton two;
    JButton three;
    JLabel label1, label2;
    ButtonGroup bg;
    JRadioButton r1;
    JRadioButton r2;
    JRadioButton r3;
    JCheckBox checkBox1;
    JCheckBox checkBox2;

    String pizza[] = {"Pepporoni Pizza", "Cheese Pizza", "Barbeque Pizza", 
        "Pineapple Pizza", "Mushroom Pizza"};
    JComboBox cb;
    JTextField t1;
    JPanel panel;
    JMenuBar jb;
    JMenu menu;
    JMenu submenu;
    JMenuItem i1;
    JMenuItem i2;
    JMenuItem i3;
    JMenuItem i4;

    public void init() {
        JFrame f = new JFrame();
                
        ImageIcon image1 = new ImageIcon("src/images/veggie.jpeg");
        ImageIcon image2 = new ImageIcon("src/images/non-veg.jpeg");
        Image img = image1.getImage();
        Image img2 = image2.getImage();
        Image newsize1 = img.getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        Image newsize2 = img2.getScaledInstance(40, 40, java.awt.Image.SCALE_SMOOTH);
        ImageIcon imageIcon1 = new ImageIcon(newsize1);
        ImageIcon imageIcon2 = new ImageIcon(newsize2);

        one = new JButton("Step-1");
        one.setBounds(50, 100, 95, 20);
        two = new JButton("Step-2");
        two.setBounds(200, 100, 95, 20);
        three = new JButton("Step-3");
        three.setBounds(350, 100, 95, 20);

        one.addActionListener(this);
        one.setActionCommand("ONE");
        two.addActionListener(this);
        two.setActionCommand("TWO");
        three.setActionCommand("THREE");
        three.addActionListener(this);
        
        label1 = new JLabel("Pepporoni",imageIcon2, JLabel.CENTER);
        label1.setBounds(200, 200, 150, 30);
        label2 = new JLabel("<HTML><FONT COLOR=GREEN>Veggie"
                + "</FONT>Delight", imageIcon1, JLabel.CENTER);
        label2.setBounds(350, 200, 150, 30);
        
        r1 = new JRadioButton("A) Small");
        r1.setBounds(50, 300, 150, 50);
        r1.addActionListener(this);
        r1.setActionCommand("SMALL");

        r2 = new JRadioButton("B) Medium");
        r2.setBounds(50, 350, 150, 50);
        r2.addActionListener(this);
        r2.setActionCommand("MEDIUM");

        r3 = new JRadioButton("C) Large");
        r3.setBounds(50, 400, 150, 50);
        r3.addActionListener(this);
        r3.setActionCommand("LARGE");

        bg = new ButtonGroup();
        bg.add(r1);
        bg.add(r2);
        bg.add(r3);
        
        checkBox1 = new JCheckBox("Double CheeseBurst");
        checkBox1.setBounds(50, 500, 200, 50);
        checkBox2 = new JCheckBox("Thin Crust", true);
        checkBox2.setBounds(300, 500, 150, 50);
        cb = new JComboBox(pizza);
        cb.setBounds(450, 300, 150, 20);
        cb.setToolTipText("Select your pizza !!");
        cb.addActionListener(new ActionListener() {  
            public void actionPerformed(ActionEvent e) {
                System.out.println(cb.getItemAt(cb.getSelectedIndex()));
            }
        });

        t1 = new JTextField("Place your Order !!!");
        t1.setBounds(50, 550, 500, 100);
      

        panel = new JPanel();
        panel.setBounds(200, 300, 200, 200);
        panel.setBackground(Color.GRAY);
        panel.setBorder(BorderFactory.createTitledBorder("Toppings"));
        JButton b1 = new JButton("Onions");
        b1.setBounds(50, 100, 80, 30);
        b1.setBackground(Color.yellow);
        JButton b2 = new JButton("Olives");
        b2.setBounds(100, 100, 80, 30);
        b2.setBackground(Color.green);
        panel.add(b1);
        panel.add(b2);
        b1.addActionListener(new ActionListener() {  
            public void actionPerformed(ActionEvent e) {
                System.out.println("Onions added");
            }
        });
        b2.addActionListener(new ActionListener() {  
            public void actionPerformed(ActionEvent e) {
                System.out.println("Olives added");
            }
        });

        jb = new JMenuBar();
        menu = new JMenu("Menu");
        submenu = new JMenu("Eat");
        i1 = new JMenuItem("Order");
        i2 = new JMenuItem("Exit");
        i3 = new JMenuItem("Here");
        i4 = new JMenuItem("To go");
        menu.add(i1);
        menu.add(submenu);
        menu.add(i2);
        submenu.add(i3);
        submenu.add(i4);
       
        
        jb.add(menu);
        f.setJMenuBar(jb);

        f.add(one);
        f.add(two);
        f.add(three);
        f.add(label1);
        f.add(label2);
        f.add(r1);
        f.add(r2);
        f.add(r3);
        f.add(checkBox1);
        f.add(checkBox2);
        f.add(cb);
        f.add(t1);
        f.add(panel);
        f.add(jb);
        
        
        

        f.setSize(600, 900);
        f.setLayout(null);
        f.setVisible(true);

    }

    public static void main(String[] args) {
        JButtonEx jx;
        jx = new JButtonEx() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String command = e.getActionCommand();
                if (command.equals("ONE")) {
                    System.out.println("Brwose through your choice.");
                } else if (command.equals("TWO")) {
                    System.out.println("Add your order");
                } else if (command.equals("THREE")) {
                    System.out.println("Way to go!!");
                }else if (command.equals("SMALL")) {
                    JOptionPane.showMessageDialog(this,"You selected Small");
                }else if (command.equals("MEDIUM")) {
                    JOptionPane.showMessageDialog(this,"You selected Medium");
                }else if (command.equals("LARGE")) {
                    JOptionPane.showMessageDialog(this,"You selected Large");
                }
            }
        };
        jx.init();
    }

}
