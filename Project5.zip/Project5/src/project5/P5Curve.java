/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project5;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.QuadCurve2D;

/**
 *
 * @author sugandhakher
 */
public class P5Curve implements P5Shape{
    // Member variables
    private int x1, y1, x2, y2;
    private Color color;
    
    public P5Curve(int x1, int y1, int x2, int y2, Color c) {
        this.x1= x1;
        this.y1=y1;
        this.x2 = x2;
        this.y2 = y2;
        this.color = c;
        
    }
    
    @Override
    public void paint(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setStroke(new BasicStroke(3));
        g.setColor(color);
        QuadCurve2D.Double curve = new QuadCurve2D.Double(x1, y1, x1-100,y1-100 ,x2,y2);
        ((Graphics2D)g).draw(curve);
    }
}
