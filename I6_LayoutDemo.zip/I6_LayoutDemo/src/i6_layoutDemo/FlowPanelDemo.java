package i6_layoutDemo;

import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 * FlowPanelDemo makes a panel with a specific layout manager and a defined set
 * of sub-components.
 *
 */
public class FlowPanelDemo extends JPanel implements ActionListener {
    private static JDialog d;
    FlowPanelDemo() {
        setLayout(new FlowLayout(FlowLayout.CENTER));
        JButton b1 = new JButton("PLACES");
        b1.addActionListener(this);
        b1.setActionCommand("ONE");
        JButton b2 = new JButton("CAMPS");
        b2.addActionListener(this);
        b2.setActionCommand("TWO");
        JButton b3 = new JButton("UTILITIES");
        b3.addActionListener(this);
        b3.setActionCommand("THREE");
        JButton b4 = new JButton("LOCATION");
        b4.addActionListener(this);
        b4.setActionCommand("FOUR");

        add(b1);
        add(b2);
        add(b3);
        add(b4);

        setSize(300, 300);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        JFrame f = new JFrame();
        if (command.equals("ONE")) {
           
            //JFrame f = new JFrame();
            d = new JDialog(f, "Places available", true);
            d.setLayout(new FlowLayout());
            JButton b1 = new JButton("NEW-HampShire");
            JButton b2 = new JButton("Boston");
            JButton b3 = new JButton("Maine");
            JButton b4 = new JButton("Florida");
            b1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    FlowPanelDemo.d.setVisible(false);
                }
            });
            d.add(new JLabel("Click the place you want to search."));
            d.add(b1);
            d.add(b2);
            d.add(b3);
            d.add(b4);
            d.setSize(500, 500);
            d.setVisible(true);

        }
        else if (command.equals("TWO")) {
           
            //JFrame f = new JFrame();
            d = new JDialog(f, "Camps available", true);
            d.setLayout(new FlowLayout());
            JButton b1 = new JButton("NEW-HampShire");
            JButton b2 = new JButton("Boston");
            JButton b3 = new JButton("Maine");
            JButton b4 = new JButton("Florida");
            b1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    FlowPanelDemo.d.setVisible(false);
                }
            });
            d.add(new JLabel("Click the place where you want to search for camp location."));
            d.add(b1);
            d.add(b2);
            d.add(b3);
            d.add(b4);
            d.setSize(500, 500);
            d.setVisible(true);

        }
        else if (command.equals("THREE")) {
           
            //JFrame f = new JFrame();
            d = new JDialog(f, "Utilities available", true);
            d.setLayout(new FlowLayout());
            JButton b1 = new JButton("Camps");
            JButton b2 = new JButton("Ropes");
            JButton b3 = new JButton("Mirror");
            JButton b4 = new JButton("Breakfast");
            b1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    FlowPanelDemo.d.setVisible(false);
                }
            });
            d.add(new JLabel("Click for what all kind of utilities are available at the capm location"));
            d.add(b1);
            d.add(b2);
            d.add(b3);
            d.add(b4);
            d.setSize(500, 500);
            d.setVisible(true);

        }
        else if (command.equals("FOUR")) {
           
            //JFrame f = new JFrame();
            d = new JDialog(f, "Type of location available:", true);
            d.setLayout(new FlowLayout());
            JButton b1 = new JButton("Greenery");
            JButton b2 = new JButton("Water-body");
            JButton b3 = new JButton("Trees");
            b1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    FlowPanelDemo.d.setVisible(false);
                }
            });
            d.add(new JLabel("Click for what all kind of utilities are available at the capm location"));
            d.add(b1);
            d.add(b2);
            d.add(b3);
            d.setSize(500, 500);
            d.setVisible(true);

        }
        f.pack();

    }
}
