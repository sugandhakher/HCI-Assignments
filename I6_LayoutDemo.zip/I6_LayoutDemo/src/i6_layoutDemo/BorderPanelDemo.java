package i6_layoutDemo;

import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 * FlowPanelDemo makes a panel with a specific layout manager and a defined set
 * of sub-components. This can be relatively simple. I only made this a separate
 * class to make the code more modular and hopefully simplify your code later.
 *
 */
public class BorderPanelDemo extends JPanel implements ActionListener {

    private static JDialog d;

    BorderPanelDemo() {
        setLayout(new BorderLayout());
        JButton b1 = new JButton("NORTH");
        b1.addActionListener(this);
        b1.setActionCommand("NORTH");
        JButton b2 = new JButton("SOUTH");
        b2.addActionListener(this);
        b2.setActionCommand("SOUTH");
        JButton b3 = new JButton("EAST");
        b3.addActionListener(this);
        b3.setActionCommand("EAST");
        JButton b4 = new JButton("WEST");
        b4.addActionListener(this);
        b4.setActionCommand("WEST");
        JButton b5 = new JButton("CENTER");
        b5.addActionListener(this);
        b5.setActionCommand("CENTER");

        add(b1, BorderLayout.NORTH);
        add(b2, BorderLayout.SOUTH);
        add(b3, BorderLayout.EAST);
        add(b4, BorderLayout.WEST);
        add(b5, BorderLayout.CENTER);

        setSize(300, 300);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        JFrame frame = new JFrame();
        if (command.equals("CENTER")) {
            //JFrame frame = new JFrame();
            JPanel panel = new JPanel();
            panel.setLayout(new FlowLayout());
            JLabel label = new JLabel("You have reached the Campsites of Central England!!");
            JButton button = new JButton();
            button.setText("Good-Luck");
            panel.add(label);
            panel.add(button);
            frame.add(panel);
            frame.setSize(500, 500);
            frame.setLocationRelativeTo(null);
            //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        }

        else if (command.equals("WEST")) {
            //final JFrame frame = new JFrame("Scroll Pane Example");

            // Display the window.  
            frame.setSize(500, 500);
            frame.setVisible(true);
            //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // set flow layout for the frame  
            frame.getContentPane().setLayout(new FlowLayout());

            JTextArea textArea = new JTextArea(20, 20);
            JScrollPane scrollableTextArea = new JScrollPane(textArea);

            scrollableTextArea.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
            scrollableTextArea.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            frame.getContentPane().add(scrollableTextArea);
        }
        else if (command.equals("EAST")) {
            //final JFrame frame = new JFrame("Scroll Pane Example");

            // Display the window.  
            frame.setSize(500, 500);
            frame.setVisible(true);
            //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // set flow layout for the frame  
            frame.getContentPane().setLayout(new FlowLayout());

            JTextArea textArea = new JTextArea(20, 20);
            JScrollPane scrollableTextArea = new JScrollPane(textArea);

            scrollableTextArea.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
            scrollableTextArea.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            frame.getContentPane().add(scrollableTextArea);
        }
        else if (command.equals("SOUTH")) {
           // final JFrame frame = new JFrame("Scroll Pane Example");

            // Display the window.  
            frame.setSize(500, 500);
            frame.setVisible(true);
            //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // set flow layout for the frame  
            frame.getContentPane().setLayout(new FlowLayout());

            JTextArea textArea = new JTextArea(20, 20);
            JScrollPane scrollableTextArea = new JScrollPane(textArea);

            scrollableTextArea.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
            scrollableTextArea.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            frame.getContentPane().add(scrollableTextArea);
        }
        else if (command.equals("NORTH")) {
            //final JFrame frame = new JFrame("Scroll Pane Example");

            // Display the window.  
            frame.setSize(500, 500);
            frame.setVisible(true);
            //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // set flow layout for the frame  
            frame.getContentPane().setLayout(new FlowLayout());

            JTextArea textArea = new JTextArea(20, 20);
            JScrollPane scrollableTextArea = new JScrollPane(textArea);

            scrollableTextArea.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
            scrollableTextArea.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            frame.getContentPane().add(scrollableTextArea);
        }
        frame.pack();
    }

}
