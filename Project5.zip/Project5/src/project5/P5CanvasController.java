/*
 * The controller class for the drawing canvas. Note this needs access
 * to the model/view
 */
package project5;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


/**
 * An implementation of MouseAdapter so you can handle any mouse events you wish.
 * @author David Sprague
 */
public class P5CanvasController extends MouseAdapter {
    public P5CanvasController(P5Canvas c) {
        canvas = c;
    }
    
//    private P5Rectangle rect = new P5Rectangle(0, 0, 100, 50, Color.BLUE);
//    int preX, preY;
    
    @Override
    public void mousePressed(MouseEvent me) {

        canvas.startDrag(me.getPoint());
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        canvas.endDrag(me.getPoint());
    }
    
    
    public void mouseMoved(MouseEvent me){
        canvas.move(me.getPoint());
    }
    public void mouseDragged(MouseEvent me){
        canvas.drag(me.getPoint());
    }
    
    // Member Variables
    P5Canvas canvas;
    
}
