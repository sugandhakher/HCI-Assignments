package i6_layoutDemo;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GridPanelDemo extends JPanel implements ActionListener {

    GridPanelDemo() {
        setLayout(new GridLayout(3,3));
        JButton b1 = new JButton("1");
        JButton b2 = new JButton("2");
        JButton b3 = new JButton("3");
        JButton b4 = new JButton("4");
        JButton b5 = new JButton("5");
        JButton b6 = new JButton("6");
        JButton b7 = new JButton("7");
        JButton b8 = new JButton("8");
        JButton b9 = new JButton("9");
        b5.addActionListener(this);
        b5.setActionCommand("ONE");

        add(b1);
        add(b2);
        add(b3);
        add(b4);
        add(b5);
        add(b6);
        add(b7);
        add(b8);
        add(b9);
       

        
        //setting grid layout of 3 rows and 3 columns  

        setSize(300, 300);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("ONE")) {

            JFrame f = new JFrame();
//            f=new JFrame();  
            JTextArea ta = new JTextArea(200, 200);
            JPanel p1 = new JPanel();
            p1.add(ta);
            JPanel p2 = new JPanel();
            JPanel p3 = new JPanel();
            JTabbedPane tp = new JTabbedPane();
            tp.setBounds(50, 50, 200, 200);
            tp.add("main", p1);
            tp.add("visit", p2);
            tp.add("help", p3);
            f.add(tp);
            f.setSize(400, 400);
            f.pack();
            f.setLayout(null);
            f.setVisible(true);

        }

    }
}
